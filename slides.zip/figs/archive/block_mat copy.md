\begin{table}
\arrayrulecolor{white}
{\setlength\tabcolsep{4pt}%
\begin{tabular}{ccc ccc ccc ccc}
\cca{6} & \cca{2} & \cca{2} & \cca{4} & \cca{2} & \cca{2} & \cca{0} & \cca{2} & \cca{0} & \cca{0} & \cca{4} & \cca{2} \\ 
\cca{0} & \cca{6} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{4} & \cca{0} & \cca{2} & \cca{0} & \cca{4} \\
\cca{0} & \cca{0} & \cca{2} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} \\
\cca{2} & \cca{2} & \cca{2} & \cca{6} & \cca{4} & \cca{4} & \cca{0} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{2} \\
\cca{2} & \cca{0} & \cca{2} & \cca{4} & \cca{6} & \cca{2} & \cca{2} & \cca{0} & \cca{2} & \cca{4} & \cca{2} & \cca{0} \\
\cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{2} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} \\
\cca{4} & \cca{4} & \cca{0} & \cca{2} & \cca{0} & \cca{2} & \cca{6} & \cca{2} & \cca{2} & \cca{0} & \cca{2} & \cca{2} \\
\cca{2} & \cca{0} & \cca{0} & \cca{4} & \cca{4} & \cca{2} & \cca{2} & \cca{6} & \cca{2} & \cca{2} & \cca{2} & \cca{0} \\
\cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{2} & \cca{4} & \cca{4} & \cca{0} & \cca{6} & \cca{2} & \cca{2} & \cca{2} \\
\cca{2} & \cca{0} & \cca{2} & \cca{4} & \cca{2} & \cca{2} & \cca{4} & \cca{2} & \cca{2} & \cca{6} & \cca{0} & \cca{0} \\
\cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{2} & \cca{0} \\
\cca{2} & \cca{4} & \cca{2} & \cca{0} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{4} & \cca{6} \\
\end{tabular}}
\Huge $\xmapsto{P}$ \normalsize
\arrayrulecolor{white}
{\setlength\tabcolsep{4pt}%
\begin{tabular}{ccc | ccc | ccc | ccc}
\cca{6} & \cca{4} & \cca{4} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\
\cca{4} & \cca{6} & \cca{4} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\
\cca{4} & \cca{4} & \cca{6} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\\hline
\cca{2} & \cca{2} & \cca{2} & \cca{6} & \cca{4} & \cca{4} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\
\cca{2} & \cca{2} & \cca{2} & \cca{4} & \cca{6} & \cca{4} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\
\cca{2} & \cca{2} & \cca{2} & \cca{4} & \cca{4} & \cca{6} & \cca{2} & \cca{2} & \cca{2} & \cca{0} & \cca{0} & \cca{0} \\\hline
\cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{6} & \cca{4} & \cca{4} & \cca{0} & \cca{0} & \cca{0} \\
\cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{4} & \cca{6} & \cca{4} & \cca{0} & \cca{0} & \cca{0} \\
\cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{2} & \cca{4} & \cca{4} & \cca{6} & \cca{0} & \cca{0} & \cca{0} \\\hline
\cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{2} & \cca{0} & \cca{0} \\
\cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{2} & \cca{0} \\
\cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{0} & \cca{2} \\
\end{tabular}}
\end{table}